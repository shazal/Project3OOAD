package com.optional;

public class AccessoryKit extends Optional {

	public AccessoryKit() {
		super();
		super.base_price = 1;
		super.type = "AccessoryKit";
		// TODO Auto-generated constructor stub
	}

}
