package com.optional;

public class ProtectiveGear extends Optional {

	public ProtectiveGear() {
		super();
		super.base_price = 3;
		super.type = "ProtectiveGear";
		// TODO Auto-generated constructor stub
	}

}
