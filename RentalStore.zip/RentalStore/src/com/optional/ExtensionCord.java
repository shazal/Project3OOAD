package com.optional;

public class ExtensionCord extends Optional {

	public ExtensionCord() {
		super();
		super.base_price = 2;
		super.type = "ExtensionCord";
		// TODO Auto-generated constructor stub
	}
	
}
